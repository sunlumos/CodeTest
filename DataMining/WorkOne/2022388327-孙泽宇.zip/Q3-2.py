import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

# 读取数据
iris_df = pd.read_csv('E:\S\code\CodeTest\DataMining\WorkOne\dataset\iris.data', names=['sepal_length', 'sepal_width', 'petal_length', 'petal_width', 'class'])

# 将特征矩阵和目标向量分离
X = iris_df.iloc[:, :-1].values
y = iris_df.iloc[:, -1].values

# 绘制前2个主成分的散点图
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X)

colors = {'Iris-setosa': 'r', 'Iris-versicolor': 'g', 'Iris-virginica': 'b'}
markers = {'Iris-setosa': 'o', 'Iris-versicolor': 's', 'Iris-virginica': '^'}

plt.subplot(2, 2, 1)
for target, color in colors.items():
    plt.scatter(X_pca[y == target, 0], X_pca[y == target, 1], c=color, label=target, marker=markers[target])

plt.xlabel('PC1')
plt.ylabel('PC2')
plt.legend()
plt.title('PCA with 2 components')

# 绘制前3个主成分的散点图
pca = PCA(n_components=3)
X_pca = pca.fit_transform(X)

ax = plt.subplot(2, 2, 2, projection='3d')
for target, color in colors.items():
    ax.scatter(X_pca[y == target, 0], X_pca[y == target, 1], X_pca[y == target, 2], c=color, label=target, marker=markers[target])

ax.set_xlabel('PC1')
ax.set_ylabel('PC2')
ax.set_zlabel('PC3')
ax.legend()
ax.set_title('PCA with 3 components')

# 绘制前4个主成分的散点图
pca = PCA(n_components=4)
X_pca = pca.fit_transform(X)

plt.subplot(2, 2, 3)
for target, color in colors.items():
    plt.scatter(X_pca[y == target, 0], X_pca[y == target, 1], c=color, label=target, marker=markers[target])

plt.xlabel('PC1')
plt.ylabel('PC2')
plt.legend()
plt.title('PCA with 4 components')

plt.tight_layout()
plt.show()

